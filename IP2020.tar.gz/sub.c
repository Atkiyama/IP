#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define    MAX_PIXEL      512  // �ő�摜�T�C�Y:(Width)
#define    MAX_LINE       512  // �ő�摜�T�C�Y:(Height)

#define    SIZE_HST_X     256  // �q�X�g�O���� �T�C�Y:(Width)
#define    SIZE_HST_Y     256  // �q�X�g�O���� �T�C�Y:(Height)



void read_NOAA_data(unsigned char img_org[MAX_LINE][MAX_PIXEL], int *num_line, int *num_pixel)
{
   // NOAA AVHRR �摜�i���{�t�߁j�̓Ǎ���
   // �ԊO�摜

   FILE *data;
   int line;

    printf("  In function read NOAA data\n");

    data = fopen( "d850429.avhrr4" , "r" );
    if (data == NULL) {
        printf ("    no data in the directory \n");
        exit(-1);
    }

    // skip the 512 bytes header 
    fseek (data, 512L, SEEK_SET);

    *num_line = 480;
    *num_pixel= 512;

    for (line=0; line < *num_line; line++) {
       fread( img_org[line], *num_pixel, 1, data );
    }
    fclose(data);
}

void read_AVNIR_data(unsigned char band_image[4][MAX_LINE][MAX_PIXEL], int *num_line, int *num_pixel)
{
   // AVNIR �摜�i����ߕӁj�̓Ǎ���
   // ���g�� �S�o���h

    FILE *data[4];
    int line, band;

    char fn[4][20]={"d970510b1.avnir","d970510b2.avnir","d970510b3.avnir","d970510b4.avnir"};

    printf("  In function read AVNIR data\n");

    *num_line = 500;
    *num_pixel= 500;

    for(band=0; band<4; band++) {
       printf("    Channel [%d] = %s\n", band+1, fn[ band ]);
       data[ band ] = fopen( fn[ band ] , "r" );
       if (data[ band ] == NULL) {
	 printf ("    no data in the directory \n");
	 exit(-1);
       }

       for (line=0; line< *num_line; line++) {
	 fread( band_image[ band ][ line ], *num_pixel, 1, data[ band ] );
       }
       fclose(data[ band ]);
    }

}

void linear(unsigned char img_org[MAX_LINE][MAX_PIXEL],int fmin, int fmax,int img_new[MAX_LINE][MAX_PIXEL], int num_line, int num_pixel)
{
    // ���`�Z�x�ϊ�
    // a, b : ���͉摜�̍ŏ��l�C�ő�l  
    // c, d : �ϊ��摜�̍ŏ��l�C�ő�l�i�F�����Ă͂O�`�W�X�i�X�O�F�j�Ȃ̂ŁC�O�C�X�O�j

    int line, pixel;

    printf("  In function linear\n");

    // make program here

}

void mk_histgram(unsigned char img_org[MAX_LINE][MAX_PIXEL],int histgram[SIZE_HST_Y][SIZE_HST_X], int num_line, int num_pixel)
{

      int hist[256];
      int line, pixel;
      int value;
      int maxhist, normalized_hist;
      int i;

      printf("  In function make histgram\n");
      //      printf("  line = %d, pixel = %d\n", num_line, num_pixel);

  // �ۑ� �z�� hist �Ƀq�X�g�O�������쐬����D
  // �q�X�g�O�����̕�������256�Ƃ��C�i�Z�x�l�ɑΉ��j������

      for(value=0; value<256; value++) hist[value]=0;


      //
      // make program here
      //


     //	for(value=0; value<256; value++){
     //    printf("%d\n",hist[value]);
     // }

     // hist ��p���āC�O���t�������{

      maxhist = -9999;
      for (value=1; value<255; value++) {
	if (hist[value]>maxhist) maxhist=hist[value];
      }

      for (line=0; line<SIZE_HST_Y; line++){
	for (pixel=0; pixel<SIZE_HST_X; pixel++) histgram[line][pixel]=10000;  
      }

      printf("    max_count = %d\n",maxhist);

      if (maxhist >0) {
	for (value=0; value<256; value++){
 
	  normalized_hist = hist[value]*255 / maxhist;


	  if (normalized_hist > 255) normalized_hist=255;
	  if (normalized_hist <   0) normalized_hist=  0;

	  for (i=0; i<normalized_hist; i++){
	    if ((255-i)>=0 && (255-i)<255) histgram[255-i][value]=10; 

	  }

	}
      }
 
      for (i=0; i<256; i++){
       histgram[255][i]=10;
      }
      
}


//
// �^���̃C�Y�쐬
//
void add_noise (unsigned char img_org[MAX_LINE][MAX_PIXEL], int num_line, int num_pixel)
{
  int   n,iseed,i,pixel,line;
  printf("  In function add noises \n");

  // make program here
}




void averaged_filter(unsigned char img_org[MAX_LINE][MAX_PIXEL], int num_line, int num_pixel)
{
  int   line, pixel, iy, ix;
  int   img_tmp[MAX_LINE][MAX_PIXEL], sum;

  printf("  In function averaged_filter\n");

  // make program here

}



void median_filter(unsigned char img_org[MAX_LINE][MAX_PIXEL], int num_line, int num_pixel)
{
  int  line, pixel, iy, ix;
  int  window [9], tmp, i, j;
  int  img_tmp[MAX_LINE][MAX_PIXEL];

  printf("  In function median_filter\n");
  
  // make program here
}



void edge_sobel (unsigned char img_org[MAX_LINE][MAX_PIXEL], int num_line, int num_pixel)
{
  int   line, pixel, iy, ix;
  int   img_tmp[MAX_LINE][MAX_PIXEL];
  int   sum_x, sum_y;

  printf("  In function edge detection\n");
  // make program here
}


void unsharp_masking(unsigned char img_org[MAX_LINE][MAX_PIXEL], int num_line, int num_pixel)
{

  int   line, pixel, iy, ix;
  int   img_tmp[MAX_LINE][MAX_PIXEL];
  int   sum;

  // unsigned char tmp[SAT_Y][SAT_X];

  printf("  In function unsharpmasking\n");

}



